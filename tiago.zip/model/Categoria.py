class Categoria:
    def __init__(self, categoria, media):
        self.media = media
        self.categoria = categoria
        
    def get_categoria(self):
        return self.categoria
    def get_media(self):
        return self.media
    def set_categoria(self, categoria):
        self.categoria = categoria
    def selt_media(self, media):
        self.media = media
