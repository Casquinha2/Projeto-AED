from Controller import *
import tkinter as tk
if __name__ == '__main__':
    root = tk.Tk()
    app = Controller(root)
    root.mainloop()